# 입력받은 정수가 홀수인지 짝수인지 판별하여 결과를 출력하기.

num = int(input())

if num % 2 == 0:
    print("even")
else:
    print("odd")
